#pragma once

#define _POSIX_SOURCE 1 /* POSIX compliant source */
#define FALSE 0
#define TRUE 1


#define TRANSMITTER 0
#define RECEIVER    1

#define MAX_SIZE 256


typedef unsigned char uchar;
